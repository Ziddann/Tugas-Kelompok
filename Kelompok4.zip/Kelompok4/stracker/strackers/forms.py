from django import forms
from .models import UserProfile, Books

class UserProfileForm(forms.ModelForm):
    class Meta:
        model = UserProfile
        fields = ['username', 'email', 'gender', 'telp', 'negara', 'password']

    def __init__(self, *args, **kwargs):
        super(UserProfileForm, self).__init__(*args, **kwargs)
        self.fields['username'].widget.attrs.update({'class': 'form-control', 'placeholder': 'Hafizh Quran'})
        self.fields['email'].widget.attrs.update({'class': 'form-control', 'placeholder': 'contoh@gmail.com'})
        self.fields['telp'].widget.attrs.update({'class': 'form-control', 'placeholder': '081842586652'})
        self.fields['password'].widget.attrs.update({'class': 'form-control', 'placeholder': 'Genta123'})
        self.fields['negara'].widget = forms.Select(choices=[
            ('', 'Pilih Negara'),
            ('Malaysia', 'Malaysia'),
            ('Jepang', 'Jepang'),
            ('China', 'China'),
            ('Indonesia', 'Indonesia'),
            # Tambahkan opsi negara lainnya sesuai kebutuhan
        ])
        
        # Tambahkan opsi pilihan untuk bidang 'gender'
        self.fields['gender'].widget = forms.Select(choices=[
            ('', 'Pilih Gender'),
            ('Laki-Laki', 'Laki-Laki'),
            ('Perempuan', 'Perempuan'),
        ])
        
        # Atur atribut kelas untuk semua bidang yang diinginkan
        for field_name, field in self.fields.items():
            field.widget.attrs.update({'class': 'form-control'})
            field.label = ''

        # Hapus label yang otomatis dibuat oleh Django
        self.fields['username'].label = ''
        self.fields['email'].label = ''
        self.fields['telp'].label = ''
        self.fields['password'].label = ''
        self.fields['negara'].label = ''
        self.fields['gender'].label = ''
        
class UserLoginForm(forms.Form):
    email = forms.EmailField(max_length=255)
    password = forms.CharField(widget=forms.PasswordInput)
    
    def __init__(self, *args, **kwargs):
        super(UserLoginForm, self).__init__(*args, **kwargs)
        self.fields['email'].widget.attrs.update({'class': 'form-control', 'placeholder': 'Masukkan Email Anda Disini'})
        self.fields['password'].widget.attrs.update({'class': 'form-control', 'placeholder': 'Masukkan Password Anda Disini'})
    
        for field_name, field in self.fields.items():
            field.widget.attrs.update({'class': 'form-control'})
            field.label = ''

        # Hapus label yang otomatis dibuat oleh Django
        self.fields['email'].label = ''
        self.fields['password'].label = ''

class SearchPenggunaByEmailForm(forms.Form):
    email = forms.EmailField(label='Email', max_length=255)

class BooksForm(forms.ModelForm):
    class Meta:
        model = Books
        fields = ['nama_software', 'pengembang', 'gambar_software', 'gambar_ui', 'sistem_operasi', 'tahun_rilis', 'deskripsi_perkembangan']

        widgets = {
            'nama_software': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Nama Software'}),
            'pengembang': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Pengembang'}),
            'gambar_software': forms.FileInput(attrs={'class': 'form-control'}),
            'gambar_ui': forms.FileInput(attrs={'class': 'form-control'}),
            'sistem_operasi': forms.CheckboxSelectMultiple(),
            'tahun_rilis': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Tahun Rilis'}),
            'deskripsi_perkembangan': forms.Textarea(attrs={'class': 'form-control', 'rows': 5, 'placeholder': 'Deskripsi Perkembangan'}),
        }
        
class SearchDocumentByCode(forms.Form):
    kode = forms.CharField(max_length=4)
