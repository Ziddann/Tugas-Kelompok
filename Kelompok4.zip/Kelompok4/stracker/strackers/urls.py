from django.urls import path
from . import views

urlpatterns = [
    path('', views.register, name='register'),
    path('login/', views.login, name='login'),
    path('logout/', views.logout, name='logout'),
    path('home/', views.home, name='home'),
    path('perpustakaan/', views.perpustakaan, name='perpustakaan'),
    path('perpustakaan/search_document/', views.search_document, name='search_document'),
    path('perpustakaan/delete_book/', views.delete_book, name='delete_book'),
]
