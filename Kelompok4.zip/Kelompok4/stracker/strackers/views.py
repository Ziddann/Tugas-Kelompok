from django.shortcuts import render, redirect
from django.contrib.auth.hashers import make_password, check_password
from django.http import JsonResponse
from .forms import UserProfileForm, UserLoginForm, SearchPenggunaByEmailForm, BooksForm, SearchDocumentByCode
from .models import UserProfile, SistemOperasi, Books
from django.conf import settings
import os

def tambah_sistem_operasi():
    SistemOperasi.objects.get_or_create(nama='Windows 7')
    SistemOperasi.objects.get_or_create(nama='Windows 8')
    SistemOperasi.objects.get_or_create(nama='Windows 8.1')
    SistemOperasi.objects.get_or_create(nama='Windows 10')
    SistemOperasi.objects.get_or_create(nama='Windows 11')
    SistemOperasi.objects.get_or_create(nama='Windows Server 2016')
    SistemOperasi.objects.get_or_create(nama='Windows Server 2019')
    SistemOperasi.objects.get_or_create(nama='MacOS Catalina')
    SistemOperasi.objects.get_or_create(nama='MacOS Big Sur')
    SistemOperasi.objects.get_or_create(nama='MacOS Monterey')
    SistemOperasi.objects.get_or_create(nama='Ubuntu 20.04 LTS')
    SistemOperasi.objects.get_or_create(nama='Ubuntu 22.04 LTS')
    SistemOperasi.objects.get_or_create(nama='Fedora 35')
    SistemOperasi.objects.get_or_create(nama='CentOS 8')
    SistemOperasi.objects.get_or_create(nama='Debian 11')
    SistemOperasi.objects.get_or_create(nama='Chrome OS 91')
    SistemOperasi.objects.get_or_create(nama='Chrome OS 92')
    SistemOperasi.objects.get_or_create(nama='Android 4.4 KitKat')
    SistemOperasi.objects.get_or_create(nama='Android 5.0 Lollipop')
    SistemOperasi.objects.get_or_create(nama='Android 6.0 Marshmallow')
    SistemOperasi.objects.get_or_create(nama='Android 7.0 Nougat')
    SistemOperasi.objects.get_or_create(nama='Android 8.0 Oreo')
    SistemOperasi.objects.get_or_create(nama='Android 9.0 Pie')
    SistemOperasi.objects.get_or_create(nama='Android 10')
    SistemOperasi.objects.get_or_create(nama='Android 11')
    SistemOperasi.objects.get_or_create(nama='Android 12')
    SistemOperasi.objects.get_or_create(nama='Android 13')
    SistemOperasi.objects.get_or_create(nama='Android 14')
    SistemOperasi.objects.get_or_create(nama='iOS 10')
    SistemOperasi.objects.get_or_create(nama='iOS 11')
    SistemOperasi.objects.get_or_create(nama='iOS 12')
    SistemOperasi.objects.get_or_create(nama='iOS 13')
    SistemOperasi.objects.get_or_create(nama='iOS 14')
    SistemOperasi.objects.get_or_create(nama='iOS 15')
    
    
tambah_sistem_operasi()

def register(request):
    if request.method == 'POST':
        form = UserProfileForm(request.POST)
        if form.is_valid():
            form.cleaned_data['gender'] = form.cleaned_data['gender'].lower()
            form.save()
            print("Data yang diinput:", form.cleaned_data)
            return redirect('login')
    else:
        form = UserProfileForm()
    return render(request, 'register.html', {'form': form})

def login(request):
    error_message = None
    search_form = SearchPenggunaByEmailForm()
    if request.method == 'POST':
        search_form = SearchPenggunaByEmailForm(request.POST)
        if search_form.is_valid():
            email = search_form.cleaned_data['email']
            user = UserProfile.objects.filter(email=email).first()
            if user:
                input_password = request.POST.get('password')
                if input_password == user.password:
                    request.session['user_id'] = user.id
                    return redirect('home')
                else:
                    error_message = "Password salah."
            else:
                error_message = "User tidak ditemukan."
    form = UserLoginForm()
    return render(request, 'login.html', {'form': form, 'search_form': search_form, 'error_message': error_message})

def logout(request):
    return render(request, 'login.html')

def home(request):
    return render(request, 'home.html')

def search_document(request):
    if request.method == 'POST':
        searchkode_form = SearchDocumentByCode(request.POST)
        if searchkode_form.is_valid():
            kode = searchkode_form.cleaned_data['kode']
            book = Books.objects.filter(kodebuku=kode).first()
            if book:
                data = {
                    'kodebuku': book.kodebuku,
                    'nama_software': book.nama_software,
                    'pengembang': book.pengembang,
                    'sistem_operasi': ', '.join([os.nama for os in book.sistem_operasi.all()]),
                    'tahun_rilis': book.tahun_rilis,
                    'deskripsi_perkembangan': book.deskripsi_perkembangan,
                    'gambar_software': book.gambar_software.url,
                    'gambar_ui': book.gambar_ui.url,
                }
                return JsonResponse(data)
    return JsonResponse({'error': 'Buku tidak ditemukan'}, status=404)

def delete_book(request):
    if request.method == 'POST':
        kode_buku = request.POST.get('kode')
        try:
            book = Books.objects.get(kodebuku=kode_buku)
            if book.gambar_software:
                path_software_image = os.path.join(settings.MEDIA_ROOT, str(book.gambar_software))
                if os.path.exists(path_software_image):
                    os.remove(path_software_image)
            if book.gambar_ui:
                path_ui_image = os.path.join(settings.MEDIA_ROOT, str(book.gambar_ui))
                if os.path.exists(path_ui_image):
                    os.remove(path_ui_image)
            book.delete()
            return JsonResponse({'message': 'Data berhasil dihapus.'})
        except Books.DoesNotExist:
            return JsonResponse({'message': 'Buku tidak ditemukan.'}, status=404)
    else:
        return JsonResponse({'message': 'Metode tidak diizinkan.'}, status=405)   

def perpustakaan(request):
    if request.method == 'POST':
        form = BooksForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('perpustakaan')
    else:
        form = BooksForm()
    books = Books.objects.all()
    sistem_operasi = SistemOperasi.objects.all()
    return render(request, 'perpustakaan.html', {'form': form, 'sistem_operasi': sistem_operasi, 'books': books})