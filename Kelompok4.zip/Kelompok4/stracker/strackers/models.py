from django.db import models
import random

class UserProfile(models.Model):
    GENDER_CHOICES = [
        ('Laki-Laki', 'Laki-Laki'),
        ('Perempuan', 'Perempuan'),
    ]
    username = models.CharField(max_length=255)
    email = models.EmailField(unique=True)
    gender = models.CharField(max_length=9, choices=GENDER_CHOICES)
    telp = models.CharField(max_length=15)
    negara = models.CharField(max_length=50)
    password = models.CharField(max_length=255)
    
def generate_random_code():
    return ''.join(random.choices('0123456789ABCDEF', k=4))
    
class Books(models.Model):
    kodebuku = models.CharField(max_length=4, default=generate_random_code, unique=True)
    nama_software = models.CharField(max_length=100)
    pengembang = models.CharField(max_length=255)
    gambar_software = models.ImageField(upload_to='software_images/')
    gambar_ui = models.ImageField(upload_to='ui_images/')
    sistem_operasi = models.ManyToManyField('SistemOperasi')
    tahun_rilis = models.CharField(max_length=50)
    deskripsi_perkembangan = models.TextField()

class SistemOperasi(models.Model):
    nama = models.CharField(max_length=100)

    def __str__(self):
        return self.nama